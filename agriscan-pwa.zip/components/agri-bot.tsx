"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Bot, X, Mic, Send, Volume2 } from "lucide-react"
import Image from "next/image"

export default function AgriBot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<{ text: string; sender: "user" | "bot" }[]>([
    { text: "Hello! I'm AgriBot. How can I help you with your crops today?", sender: "bot" },
  ])
  const [input, setInput] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [speechSupported, setSpeechSupported] = useState(false)

  useEffect(() => {
    // Check if speech recognition is supported
    setSpeechSupported("SpeechRecognition" in window || "webkitSpeechRecognition" in window)

    // Scroll to bottom of messages
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [messages])

  const toggleChat = () => {
    setIsOpen(!isOpen)
  }

  const handleSend = () => {
    if (input.trim()) {
      // Add user message
      setMessages([...messages, { text: input, sender: "user" }])

      // Simulate bot response (in a real app, this would call an AI service)
      setTimeout(() => {
        let botResponse = "I'm processing your question about crops..."

        // Simple pattern matching for demo purposes
        if (input.toLowerCase().includes("tomato") && input.toLowerCase().includes("spot")) {
          botResponse =
            "It sounds like your tomatoes might have early blight. This is a fungal disease that causes dark spots on lower leaves. I recommend removing affected leaves and applying an organic fungicide."
        } else if (input.toLowerCase().includes("white") && input.toLowerCase().includes("bug")) {
          botResponse =
            "Those might be whiteflies or aphids. Try spraying with neem oil solution or introducing ladybugs as natural predators."
        }

        setMessages((prev) => [...prev, { text: botResponse, sender: "bot" }])

        // Text-to-speech for bot response
        if ("speechSynthesis" in window) {
          const speech = new SpeechSynthesisUtterance(botResponse)
          speech.lang = localStorage.getItem("language") || "en"
          window.speechSynthesis.speak(speech)
        }
      }, 1000)

      setInput("")
    }
  }

  const handleVoiceInput = () => {
    if (!speechSupported) return

    setIsRecording(true)

    // Use Web Speech API for voice recognition
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    const recognition = new SpeechRecognition()

    recognition.lang = localStorage.getItem("language") || "en"
    recognition.continuous = false
    recognition.interimResults = false

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript
      setInput(transcript)
      setIsRecording(false)
    }

    recognition.onerror = () => {
      setIsRecording(false)
    }

    recognition.onend = () => {
      setIsRecording(false)
    }

    recognition.start()
  }

  const speakMessage = (text: string) => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel() // Stop any current speech
      const speech = new SpeechSynthesisUtterance(text)
      speech.lang = localStorage.getItem("language") || "en"
      window.speechSynthesis.speak(speech)
    }
  }

  return (
    <>
      {/* Floating button */}
      <Button
        onClick={toggleChat}
        className={`fixed bottom-4 right-4 rounded-full w-14 h-14 shadow-lg ${
          isOpen ? "bg-red-500 hover:bg-red-600" : "bg-green-500 hover:bg-green-600"
        } transition-all duration-300 z-50`}
      >
        {isOpen ? <X className="h-6 w-6" /> : <Bot className="h-6 w-6" />}
      </Button>

      {/* Chat window */}
      {isOpen && (
        <Card className="fixed bottom-20 right-4 w-80 sm:w-96 h-[500px] shadow-xl z-40 flex flex-col overflow-hidden border-green-200">
          <div className="bg-green-600 text-white p-3 flex items-center justify-between">
            <div className="flex items-center">
              <div className="relative w-8 h-8 mr-2 bg-white rounded-full overflow-hidden">
                <Image
                  src="/placeholder.svg?height=32&width=32"
                  alt="AgriBot"
                  width={32}
                  height={32}
                  className="agribot-avatar"
                />
              </div>
              <span className="font-medium">AgriBot</span>
            </div>
            <span className="text-xs bg-green-700 px-2 py-1 rounded-full">Farmer Buddy</span>
          </div>

          <div className="flex-1 overflow-y-auto p-3 bg-gray-50">
            {messages.map((message, index) => (
              <div key={index} className={`mb-3 flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    message.sender === "user"
                      ? "bg-green-600 text-white rounded-tr-none"
                      : "bg-white border border-gray-200 rounded-tl-none"
                  }`}
                >
                  {message.text}
                  {message.sender === "bot" && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 ml-1 opacity-70 hover:opacity-100"
                      onClick={() => speakMessage(message.text)}
                    >
                      <Volume2 className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-3 border-t bg-white">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                className={`flex-shrink-0 ${isRecording ? "bg-red-100 text-red-500 animate-pulse" : ""}`}
                onClick={handleVoiceInput}
                disabled={!speechSupported}
              >
                <Mic className="h-4 w-4" />
              </Button>

              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your question..."
                className="flex-1"
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
              />

              <Button
                variant="default"
                size="icon"
                className="flex-shrink-0 bg-green-600 hover:bg-green-700"
                onClick={handleSend}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </Card>
      )}
    </>
  )
}

