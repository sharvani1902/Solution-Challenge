"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Upload, FileImage } from "lucide-react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import AgriBot from "@/components/agri-bot"

export default function UploadPage() {
  const router = useRouter()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [dragActive, setDragActive] = useState(false)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      processFile(file)
    }
  }

  const processFile = (file: File) => {
    // Check if file is an image
    if (!file.type.startsWith("image/")) {
      alert("Please upload an image file")
      return
    }

    // Check file size (limit to 10MB)
    if (file.size > 10 * 1024 * 1024) {
      alert("File size should be less than 10MB")
      return
    }

    const reader = new FileReader()
    reader.onload = (e) => {
      const result = e.target?.result as string
      setSelectedImage(result)
    }
    reader.readAsDataURL(file)
  }

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()

    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0])
    }
  }

  const analyzeImage = () => {
    if (!selectedImage) return

    setAnalyzing(true)

    // In a real app, this would send the image to a TensorFlow.js model
    // or an API for analysis. Here we'll simulate a delay and redirect.
    setTimeout(() => {
      // Store the image in localStorage (in a real app, you might use IndexedDB)
      localStorage.setItem("lastScannedImage", selectedImage)

      // Redirect to results page
      router.push("/results")
    }, 3000)
  }

  const triggerFileInput = () => {
    fileInputRef.current?.click()
  }

  return (
    <main className="flex min-h-screen flex-col items-center p-4 bg-gradient-to-b from-green-50 to-yellow-50">
      <div className="w-full max-w-md flex justify-between items-center mb-6">
        <Button variant="ghost" size="icon" onClick={() => router.push("/")} className="text-green-700">
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold text-green-700">Upload Image</h1>
        <div className="w-10"></div> {/* Spacer for alignment */}
      </div>

      <Card className="w-full max-w-md overflow-hidden shadow-lg border-green-100 mb-6">
        {!selectedImage ? (
          <div
            className={`p-8 flex flex-col items-center justify-center min-h-[300px] border-2 border-dashed ${
              dragActive ? "border-green-500 bg-green-50" : "border-gray-300"
            } rounded-lg transition-colors`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <FileImage className="h-16 w-16 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-700 mb-2">Upload your crop image</h3>
            <p className="text-sm text-gray-500 text-center mb-6">Drag and drop your image here, or click to browse</p>
            <Button onClick={triggerFileInput} className="bg-green-600 hover:bg-green-700">
              <Upload className="mr-2 h-4 w-4" />
              Select Image
            </Button>
            <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
          </div>
        ) : (
          <div className="relative">
            <div className="relative aspect-[3/4] w-full">
              <Image src={selectedImage || "/placeholder.svg"} alt="Selected crop" fill className="object-contain" />

              {analyzing && (
                <div className="absolute inset-0 bg-black bg-opacity-70 flex flex-col items-center justify-center">
                  <div className="relative w-20 h-20 mb-4">
                    <Image
                      src="/placeholder.svg?height=80&width=80"
                      alt="AgriBot thinking"
                      width={80}
                      height={80}
                      className="agribot-avatar"
                    />
                  </div>
                  <p className="text-white text-lg mb-2">Analyzing your crop...</p>
                  <div className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
            </div>

            {!analyzing && (
              <div className="p-4 flex justify-between">
                <Button variant="outline" onClick={() => setSelectedImage(null)}>
                  Choose Another
                </Button>
                <Button className="bg-green-600 hover:bg-green-700" onClick={analyzeImage}>
                  Analyze Crop
                </Button>
              </div>
            )}
          </div>
        )}
      </Card>

      <div className="w-full max-w-md">
        <p className="text-sm text-gray-600 text-center">
          For best results, upload a clear, well-lit image of the affected plant part. Supported formats: JPG, PNG,
          WEBP.
        </p>
      </div>

      <AgriBot />
    </main>
  )
}

