"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Search, Filter, Leaf } from "lucide-react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import AgriBot from "@/components/agri-bot"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Mock disease database
const diseasesDatabase = [
  {
    id: 1,
    name: "Early Blight",
    crop: "Tomato",
    scientificName: "Alternaria solani",
    severity: "Moderate",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 2,
    name: "Powdery Mildew",
    crop: "Cucumber",
    scientificName: "Erysiphe cichoracearum",
    severity: "Mild",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 3,
    name: "Bacterial Leaf Spot",
    crop: "Pepper",
    scientificName: "Xanthomonas campestris",
    severity: "Severe",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 4,
    name: "Rust",
    crop: "Wheat",
    scientificName: "Puccinia graminis",
    severity: "Severe",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 5,
    name: "Downy Mildew",
    crop: "Grape",
    scientificName: "Plasmopara viticola",
    severity: "Moderate",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 6,
    name: "Anthracnose",
    crop: "Mango",
    scientificName: "Colletotrichum gloeosporioides",
    severity: "Mild",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 7,
    name: "Rice Blast",
    crop: "Rice",
    scientificName: "Magnaporthe oryzae",
    severity: "Severe",
    image: "/placeholder.svg?height=200&width=200",
  },
]

export default function DatabasePage() {
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState("")
  const [cropFilter, setCropFilter] = useState("")
  const [severityFilter, setSeverityFilter] = useState("")

  // Filter diseases based on search term and filters
  const filteredDiseases = diseasesDatabase.filter((disease) => {
    const matchesSearch =
      disease.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      disease.crop.toLowerCase().includes(searchTerm.toLowerCase()) ||
      disease.scientificName.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesCrop = cropFilter ? disease.crop === cropFilter : true
    const matchesSeverity = severityFilter ? disease.severity === severityFilter : true

    return matchesSearch && matchesCrop && matchesSeverity
  })

  // Get unique crop types for filter
  const cropTypes = Array.from(new Set(diseasesDatabase.map((d) => d.crop)))

  return (
    <main className="flex min-h-screen flex-col items-center p-4 bg-gradient-to-b from-green-50 to-yellow-50">
      <div className="w-full max-w-md flex justify-between items-center mb-6">
        <Button variant="ghost" size="icon" onClick={() => router.push("/")} className="text-green-700">
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold text-green-700">Disease Database</h1>
        <div className="w-10"></div> {/* Spacer for alignment */}
      </div>

      <Card className="w-full max-w-md shadow-lg border-green-100 mb-6">
        <div className="p-4">
          <div className="relative mb-4">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search diseases, crops..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="flex gap-2 mb-2">
            <div className="flex-1">
              <Select value={cropFilter} onValueChange={setCropFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Crop Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Crops</SelectItem>
                  {cropTypes.map((crop) => (
                    <SelectItem key={crop} value={crop}>
                      {crop}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1">
              <Select value={severityFilter} onValueChange={setSeverityFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Severity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Severities</SelectItem>
                  <SelectItem value="Mild">Mild</SelectItem>
                  <SelectItem value="Moderate">Moderate</SelectItem>
                  <SelectItem value="Severe">Severe</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                setSearchTerm("")
                setCropFilter("")
                setSeverityFilter("")
              }}
              className="flex-shrink-0"
            >
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Card>

      <div className="w-full max-w-md space-y-4 mb-6">
        {filteredDiseases.length > 0 ? (
          filteredDiseases.map((disease) => (
            <Card
              key={disease.id}
              className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => router.push(`/disease/${disease.id}`)}
            >
              <div className="flex">
                <div className="w-1/3 relative">
                  <Image
                    src={disease.image || "/placeholder.svg"}
                    alt={disease.name}
                    width={100}
                    height={100}
                    className="object-cover h-full"
                  />
                </div>
                <div className="w-2/3 p-4">
                  <h3 className="font-bold text-green-800">{disease.name}</h3>
                  <div className="flex items-center text-sm text-gray-600 mb-1">
                    <Leaf className="h-3 w-3 mr-1 text-green-600" />
                    <span>{disease.crop}</span>
                  </div>
                  <p className="text-xs text-gray-500 italic mb-2">{disease.scientificName}</p>
                  <div
                    className={`text-xs inline-block px-2 py-1 rounded-full 
                    ${
                      disease.severity === "Mild"
                        ? "bg-yellow-100 text-yellow-700"
                        : disease.severity === "Moderate"
                          ? "bg-orange-100 text-orange-700"
                          : "bg-red-100 text-red-700"
                    }`}
                  >
                    {disease.severity}
                  </div>
                </div>
              </div>
            </Card>
          ))
        ) : (
          <div className="text-center p-8">
            <div className="mb-4 text-gray-400">
              <Search className="h-12 w-12 mx-auto" />
            </div>
            <h3 className="text-lg font-medium text-gray-700 mb-2">No diseases found</h3>
            <p className="text-gray-600">Try adjusting your search or filters to find what you're looking for.</p>
          </div>
        )}
      </div>

      <AgriBot />
    </main>
  )
}

